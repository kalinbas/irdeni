IRDENI (TM) - Das Verm�chtnis
README v2.0
DeadHead Studios

COPYRIGHT 2002, SimBa ENTERTAINMENT


========================================
INHALT 
========================================

1. EINF�HRUNG
2. INSTALLATION
3. GENERELL WICHTIGE INFORMATIONEN
4. VIDEOPROBLEME
5. SOUNDPROBLEME
6. STEUERUNG
7. KONTAKT

=======================================


1. EINF�HRUNG

Das vorliegende Spiel entstand in vielz�hligen Programmierstunden. Unser Ziel war es nicht, ein grafisches Meisterwerk zu schaffen. Vielmehr lag uns eine Unterhaltungssoftware am Herzen, die den Spieler ueber mehrere Stunden zu besch�ftigen weiss. 
Das meiste Blut vergossen wir beim Erschaffen des Kampfsystems und dem Studium der dazu notwendigen mathematischen Mittel. Ebenso war uns eine nicht-lineare Spielstruktur wichtig, sodass der Spieler Entscheidungen treffen kann, die sich weitergehend auf das Spielgeschehen auswirken. Die Aufgaben lassen sich zum Teil auf verschiedenste Weise l�sen. Das Projekt IRDENI entstand, soweit es uns m�glich war, aus eigenen Ideen. Wir verzichteten auf bereits bestehende Bilder und erschufen alle Grafiken im Spiel selber. Soweit, so gut :-)


2. INSTALLATION

Alle Dateien in ein beliebiges Verzeichnis auf der Festplatte kopieren. Zum Spielen IRDENI.EXE ausf�hren.


3. GENERELL WICHTIGE INFORMATIONEN

!ACHTUNG!
Es wird empfohlen keinerlei �nderungen an den Programmdateien vorzunehmen.


Falls Probleme beim Start auftreten sollten:
-Rechsklick auf das Programmsymbol (Verkn�pfung) 
-Eigenschaften
-Arbeitsspeicher
-Alle Speicherwerte auf "automatisch" �ndern!

Die im Spiel verwendeten Attribute haben die folgenden Bedeutung:
-KRAFT        Bestimmt die H�he des Schadens, den ihr im Kampf anrichtet.
-ABWEHR       Erkl�rt sich von selbst.
-GESCHICK     Ist daf�r verantwortlich, mit welcher Wahrscheinlichkeit ihr euren Gegner trefft.
-ERFAHRUNG    Die Menge gesammelter Erfahrung seit dem letzten Levelaufstieg


Wichtige Objekte:
-----------------

Tagebuch: 
Das Tagebuch enth�lt die wichtigsten Ziele. Man kann immer darin nachschlagen wenn man nicht weiterweiss.

Karte:
Im Spiel ist eine Universalkarte versteckt. Wenn ihr diese ben�tzt, habt ihr eine �bersichtskarte �ber das aktuelle Gebiet.

Schaufel: 
Die Schaufel k�nnt ihr auch auf offenem Feld benutzen. Bei Blumen, welche ihr nur mit der Schaufel ausgraben k�nnt, wird die Schaufel automatisch benutzt.

Personen:
Objekte werden nicht mit Personen ben�tzt. Wenn ihr Charakter ein Objekt �bergeben soll, ist nur eine einfacher Dialog mit der Person notwendig. 


4. GRAFIKPROBLEME 

vorerst keine Probleme


5. SOUNDPROBLEME

auch in Zukunft problemlos


6. STEUERUNG

Im Spiel:
PFEILTASTEN - Bewegen der Spielfigur
ENTER - Bet�tigen einer Aktion
LEERTASTE - Textscrollen/beschleunigen
I - Inventar
S - Speichern
ESC - Hauptmen�

Im Inventar:
D - Objektinformation abrufen
B - Objekt ben�tzen
ESC - zur�ck zum Spiel


7. KONTAKT

bebon@freesurf.ch & lordbranton@freesurf.ch
=======================================